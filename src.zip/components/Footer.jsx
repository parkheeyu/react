import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
    <h3>Copyright 2023 인하대학교 All rights reserved</h3>
    </div>
  )
}

export default Footer