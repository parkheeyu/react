import React, { useState } from 'react'

const Component3 = () => {
    const[addresses, setAddresses] =useState([
        {id:1, name :'박희윤', addresses:'인천 부평구 삼산동'},
        {id:2, name :'이소영', addresses:'인천 서구 검암동'},
        {id:3, name :'이순신', addresses:'서울 구로구 구로동'},
    ])
    
  return (
    <div>
        <h1>주소목록(12204152)</h1>
        <table>
            <thead>
            <tr>
                <td>ID.</td>
                <td>이름</td>
                <td>주소</td>
            </tr>
            </thead>
            <tbody>
                {addresses.map((add)=>
                <tr>
                    <td>{add.id}</td>
                    <td>{add.name}</td>
                    <td>{add.addresses}</td>
                </tr>)}
            </tbody>
        </table>
    </div>
  )
}

export default Component3