import React, { useRef, useState } from 'react'

const Component2 = () => {
    const ref_name =useRef(null); 
    const [form, setForm] = useState({
        name: '박희윤',
        address :'인천 부평구 삼산동',
        phone: '010-0000-0000'
    });
    const {name,address,phone} = form;
    const onRegister = (e) =>{
         e.preventDefault();
         if(window.confirm('주소를 등록하시겠습니까?')){
            alert(`이름:${name}\n주소:${address}\n전화:${phone}`);
            setForm({
                name:'',
                address:'',
                phone:''
            });
            ref_name.current.focus();

         }
    }
    const onChange =(e) => {
        setForm({
            ...form,
            [e.target.name]:e.target.value
        })
    }
  return (
    <div>
        <h1>주소등록</h1>
        <form onSubmit={onRegister}>
            <input placeholder='이름 입력' value={form.name} name ="name"
                onChange={onChange} ref={ref_name}/>
            <input placeholder='주소 입력' value={form.address} name="address"
                onChange={onChange}/>
            <input placeholder='번호 입력' value={form.phone} name="phone"
                onChange={onChange}/>
            <button>주소등록</button>
        </form>
        <hr/>
        <h1>이름 :{name}</h1>
        <h1>주소 :{address}</h1>
        <h1>전화번호 :{phone}</h1>
        </div>
  )
}

export default Component2