const Header = () => {
    return (
        <div>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0VJZH0MdR4Ud_Vdo_1mPBRcO-Ey38dVh4UQ&usqp=CAU" height={480}/>
        </div>
    )
}

export default Header;