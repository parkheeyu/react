import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import Component1 from './components/Component1';
import Component2 from './components/Component2';
import Component3 from './components/Component3';

const App = () => {
  return (
    <div className ="App">
      <Header/>
      <h1>리액트아자자자자자</h1>
      <Component1/>
      <Component2/>
      <Component3/>
      <Footer/>
    </div>
  );
}


export default App;
